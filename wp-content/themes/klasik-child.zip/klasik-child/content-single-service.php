<div class="single-service">

   <img src="<?php the_field('icon'); ?>" alt=""> 
    
    <?php the_title(); ?>       
    <?php the_content(); ?>

   

    <div class="clear"></div>
    
</div><!-- #post -->